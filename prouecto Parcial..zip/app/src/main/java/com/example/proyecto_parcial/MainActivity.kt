package com.example.proyecto_parcial

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    private var num1 = 0.0
    private var num2 = 0.0
    private var operacion = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        TextResultado.text = "0"
        operacion = NO_OPERACION

   botonUno.setOnClickListener{numeroPresionado("1")}
        botonDos.setOnClickListener{numeroPresionado("2")}
        botonTres.setOnClickListener{numeroPresionado("3")}
        botonCuatro.setOnClickListener{numeroPresionado("4")}
        bononCinco.setOnClickListener{numeroPresionado("5")}
        botonSeis.setOnClickListener{numeroPresionado("6")}
        botonSiete.setOnClickListener{numeroPresionado("7")}
        botonOcho.setOnClickListener{numeroPresionado("8")}
        botonNueve.setOnClickListener{numeroPresionado("9")}
        botonCero.setOnClickListener{numeroPresionado("0")}
        botonPunto.setOnClickListener{numeroPresionado(".")}



        botonsuma.setOnClickListener {operacionP(SUMA)}
        botonResta.setOnClickListener {operacionP(RESTA)}
        botonDivison.setOnClickListener {operacionP(DIVISON)}


        buttonBorrar.setOnClickListener{
            num1 =0.0
            num2 =0.0
            TextResultado.text = "0"
            operacion = NO_OPERACION
        }
     botonIgual.setOnClickListener{
         var resultado = when(operacion){
             SUMA -> num1 + num2
             RESTA -> num1 - num2
             MULTIPLICACION -> num1 * num2
             DIVISON -> num1/num2
             else -> 0
         }
        TextResultado.text =resultado.toString()
     }

    }
    private fun numeroPresionado(digito: String)
    {
        if(TextResultado.text == "0" && digito != ".") {
            TextResultado.text = "$digito"
        } else {
            TextResultado.text = "${TextResultado.text}$digito"
        }

        if(operacion == NO_OPERACION){
            num1 = TextResultado.text.toString().toDouble()
        } else {
            num2 = TextResultado.text.toString().toDouble()
        }
    }
    private fun operacionP(operacion: Int)
    {
        this.operacion = operacion
        num1 = TextResultado.text.toString().toDouble()

        TextResultado.text = "0"
    }

    private fun resolverP(){

        val resultado = when(operacion) {
            SUMA -> num1 + num2
            RESTA -> num1 - num2
            MULTIPLICACION -> num1 * num2
            DIVISON -> num1 / num2
            else -> 0
        }

        num1 = resultado as Double

        TextResultado.text = if("$resultado".endsWith(".0")) { "$resultado".replace(".0","") } else { "%.2f".format(resultado) }
    }
    companion object{
        const val SUMA = 1
        const val RESTA = 2
        const val MULTIPLICACION = 3
        const val DIVISON = 4
        const val NO_OPERACION =5
    }
}